module Sorpresa
  IRCARCEL = :ircacrcel;
  IRCASILLA = :ircasilla;
  PAGARCOBRAR = :pagarcobrar;
  PORCASAHOTEL = :porcasahotel;
  PORJUGADOR = :porjugador;
  SALIRCARCEL = :salircarcel; 
end
