#include <iostream>
#include "Diccionario.h"

using namespace std;

int main(){
  Diccionario<int, int> mi;

  Diccionario<int, int>::iterator it = mi.begin();
}
