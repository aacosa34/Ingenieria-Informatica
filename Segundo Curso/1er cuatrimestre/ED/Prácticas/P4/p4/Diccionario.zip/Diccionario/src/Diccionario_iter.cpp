template <class T, class U>
Diccionario<T,U>::iterator::iterator(){
  this.vit = NULL;
}


template <class T, class U>
Diccionario<T, U>::iterator::iterator(const iterator &it) {
  vit = it.vit;
}


template <class T, class U>
typename Diccionario<T, U>::iterator &
Diccionario<T, U>::iterator::operator=(const iterator &it) {
  if (this != &it) {
    this -> vit = it.vit;
  }

  return *this;
}


template <class T, class U>
typename Diccionario<T,U>::iterator & Diccionario<T,U>::iterator::operator++(){
  this -> vit++;

  return *this;
}
