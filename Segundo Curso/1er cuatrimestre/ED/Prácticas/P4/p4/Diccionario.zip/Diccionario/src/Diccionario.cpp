// Implementacion de Diccionario
#include "Diccionario.h"

template <class T, class U> Diccionario<T,U>::Diccionario(){}

template <class T, class U>
void Diccionario<T,U>::add(const data<T,U> d){
  datos.push_back(d);
}

template <class T, class U>
typename Diccionario<T, U>::iterator Diccionario<T,U>::begin(){
  return Diccionario<T,U>::iterator(datos.begin());
}



/*
template <class T, class U>
bool Diccionario<T,U>
Esta_Clave (const T & p, list <data<T,U>> :: iterator & it_out) {
  bool status = false;

  list <data<T,U>> :: iterator pointer;

  if (!datos.empty){

    for (pointer = datos.begin(); pointer != datos.end() && !status; pointer++){

    }
  }

}
*/
