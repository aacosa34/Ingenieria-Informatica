// Iteradores Diccionario
// Pedro Antonio Mayorgas Parejo

#ifndef DICCIONARIO
#define DICCIONARIO

#include <list> // Inclusion de list STL

using namespace std;

template <class T, class U>
struct data{
  T clave;
  list<U> info_asoci;
};

template <class T, class U>
class Diccionario{
private:
  list<data<T,U>> datos;
public:
  Diccionario();
  void add(const data<T,U> d);

  // bool Esta_Clave (const T & p, typename list <data<T,U>> :: iterator & it_out);

  // Clase Diccionario<T,U>::iterator
  class iterator {
    private:
      typename list <data<T,U>>::iterator vit;

      friend class Diccionario<T, U>;
    public:
      iterator();
      iterator(const iterator &it);

      iterator &operator=(const iterator &it);

      iterator &operator++();
      //    iterator &operator--();
      //      pair<T, U> &operator*();

    //    bool operator!=(const iterator &it) const;
    //    bool operator==(const iterator &it) const;
    };

    iterator begin();

};

#include "Diccionario.cpp"
#include "Diccionario_iter.cpp"
#endif
