#include <iostream>

int main()
{
	std::cout << "¡hola, mundo!" 
	          << std::endl;
}
