#include <stdio.h>

int main()
{
	int i = 12345;
	printf("i=%d\n", i);
	return 0;
}
