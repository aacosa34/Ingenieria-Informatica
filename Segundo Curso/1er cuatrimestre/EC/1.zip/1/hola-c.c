#include <stdio.h>

int main()
{
	printf("¡hola, mundo!\n");
	return 0;
}
