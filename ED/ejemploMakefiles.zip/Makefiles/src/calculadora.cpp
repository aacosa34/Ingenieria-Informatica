#include "calculadora.h"

int suma(Numero a, Numero b){
    return a.get() + b.get();
}

int producto(Numero a, Numero b){
    return a.get() * b.get();
}
