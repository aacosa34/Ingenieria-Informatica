#include "Numero.h"

Numero::Numero(int i = 0){
    num = i;
}

int Numero::get(){
    return num;
}

void Numero::set(int i){
    num  = i;
}
