#ifndef __CALCULADORA_H_
#define __CALCULADORA_H_

#include "Numero.h"

int suma(Numero a, Numero b);
int producto(Numero a, Numero b);

#endif // __CALCULADORA_H_
