#ifndef __NUMERO__
#define __NUMERO__

class Numero{
private:
    int num;
public:
    Numero(int i);
    int get();
    void set(int i);
};

#endif
