var searchData=
[
  ['pila_5fmax_15',['Pila_max',['../classPila__max.html#a2a7e17c656ae00679fd66b2102508f4c',1,'Pila_max::Pila_max()'],['../classPila__max.html#a0a832d8e3fafb070e495b4b75955d477',1,'Pila_max::Pila_max(const Pila_max&lt; T &gt; &amp;original)'],['../classPila__max.html#a2a7e17c656ae00679fd66b2102508f4c',1,'Pila_max::Pila_max()'],['../classPila__max.html#a0a832d8e3fafb070e495b4b75955d477',1,'Pila_max::Pila_max(const Pila_max&lt; T &gt; &amp;original)']]],
  ['poner_16',['poner',['../classPila__max.html#a458d5568f20f89b8344a334da36b73c0',1,'Pila_max::poner(const T &amp;valor)'],['../classPila__max.html#a458d5568f20f89b8344a334da36b73c0',1,'Pila_max::poner(const T &amp;valor)']]]
];
