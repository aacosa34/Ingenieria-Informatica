var searchData=
[
  ['vacia_19',['vacia',['../classPila__max.html#a756f43a248269eb58e2d4bd7c43835a2',1,'Pila_max::vacia() const'],['../classPila__max.html#a756f43a248269eb58e2d4bd7c43835a2',1,'Pila_max::vacia() const']]]
];
