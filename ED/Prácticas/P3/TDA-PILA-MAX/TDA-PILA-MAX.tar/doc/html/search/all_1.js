var searchData=
[
  ['operator_3d_1',['operator=',['../classPila__max.html#a69a80a29b6837803bf964b3006ba6229',1,'Pila_max::operator=(const Pila_max&lt; T &gt; &amp;otra)'],['../classPila__max.html#a69a80a29b6837803bf964b3006ba6229',1,'Pila_max::operator=(const Pila_max&lt; T &gt; &amp;otra)']]]
];
