var searchData=
[
  ['quitar_17',['quitar',['../classPila__max.html#adb91c11d4d02c43d7d58d01be821a589',1,'Pila_max::quitar()'],['../classPila__max.html#adb91c11d4d02c43d7d58d01be821a589',1,'Pila_max::quitar()']]]
];
