var searchData=
[
  ['tope_5fpila_7',['tope_pila',['../classPila__max.html#ac190ab72ba4c3cde5be13b955e143a17',1,'Pila_max::tope_pila()'],['../classPila__max.html#a176ed6d8f8999946488299296880f14f',1,'Pila_max::tope_pila() const'],['../classPila__max.html#ac190ab72ba4c3cde5be13b955e143a17',1,'Pila_max::tope_pila()'],['../classPila__max.html#a176ed6d8f8999946488299296880f14f',1,'Pila_max::tope_pila() const']]]
];
