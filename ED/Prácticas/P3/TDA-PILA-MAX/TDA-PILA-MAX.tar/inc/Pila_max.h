#define CUAL_COMPILA 2
#if CUAL_COMPILA == 1
#include "Pila_max_Cola.h"
#elif CUAL_COMPILA == 2
#include "Pila_max_VD.h"
#endif