var searchData=
[
  ['num_5fcolumnas_33',['num_columnas',['../classImagen.html#ac28d55c18064aea2a65e6fcf51d86191',1,'Imagen']]],
  ['num_5ffilas_34',['num_filas',['../classImagen.html#a4cb4faa04f5e2913965e43a6a65acfd1',1,'Imagen']]]
];
