var searchData=
[
  ['asigna_5fpixel_24',['asigna_pixel',['../classImagen.html#a53f60c37b92d9961db30458f03f8d9c7',1,'Imagen']]]
];
