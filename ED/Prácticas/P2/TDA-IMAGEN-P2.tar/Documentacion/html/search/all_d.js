var searchData=
[
  ['zoom_19',['zoom',['../classImagen.html#aaec39d04ae353a36da51ec56610c3025',1,'Imagen']]]
];
