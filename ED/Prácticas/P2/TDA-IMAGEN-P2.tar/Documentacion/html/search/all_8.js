var searchData=
[
  ['operator_3d_14',['operator=',['../classImagen.html#a2d30fa014a342dbf0f9d992be6838adf',1,'Imagen']]]
];
