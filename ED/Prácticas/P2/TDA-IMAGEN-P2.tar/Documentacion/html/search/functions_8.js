var searchData=
[
  ['umbraliza_36',['umbraliza',['../classImagen.html#a0ced8c312eb57cf481ffb479ad73a783',1,'Imagen']]]
];
