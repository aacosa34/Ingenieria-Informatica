var searchData=
[
  ['valor_5fpixel_18',['valor_pixel',['../classImagen.html#abf37e1d9eafb1742b2d742dad6fee2bc',1,'Imagen']]]
];
