var searchData=
[
  ['imagen_5',['Imagen',['../classImagen.html',1,'Imagen'],['../classImagen.html#ab2e649aa7a105155c7bfdb846abf0528',1,'Imagen::Imagen()'],['../classImagen.html#a33f5f31d610526dbe66d04de0a827f91',1,'Imagen::Imagen(const Imagen &amp;otra)'],['../classImagen.html#a4b397c4a3dc0794cab351f96dc9390fd',1,'Imagen::Imagen(int f, int c)']]],
  ['imagen_2eh_6',['imagen.h',['../imagen_8h.html',1,'']]],
  ['imagenes_2eh_7',['imagenES.h',['../imagenES_8h.html',1,'']]]
];
