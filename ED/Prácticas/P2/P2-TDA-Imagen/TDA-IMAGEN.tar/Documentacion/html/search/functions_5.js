var searchData=
[
  ['morphing_32',['morphing',['../classImagen.html#ab58145a20af46cb6db37e1178fe04cc2',1,'Imagen']]]
];
