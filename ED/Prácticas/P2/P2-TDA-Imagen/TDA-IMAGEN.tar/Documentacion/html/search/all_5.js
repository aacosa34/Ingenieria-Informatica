var searchData=
[
  ['leerimagenpgm_8',['LeerImagenPGM',['../imagenES_8h.html#a03340a1e1e4a88385c972bb4af463649',1,'imagenES.h']]],
  ['leerimagenppm_9',['LeerImagenPPM',['../imagenES_8h.html#a05aea20533de5bbd02789f76aafbb99b',1,'imagenES.h']]],
  ['leertipoimagen_10',['LeerTipoImagen',['../imagenES_8h.html#acaa5fb277940aceed29f86c093a3d89c',1,'imagenES.h']]]
];
