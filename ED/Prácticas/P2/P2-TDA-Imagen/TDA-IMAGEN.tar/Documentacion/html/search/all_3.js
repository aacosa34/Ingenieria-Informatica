var searchData=
[
  ['escribirimagenpgm_3',['EscribirImagenPGM',['../imagenES_8h.html#a4b649cc272f02649563791d5ed75b557',1,'imagenES.h']]],
  ['escribirimagenppm_4',['EscribirImagenPPM',['../imagenES_8h.html#ae149be8653b9f8c7321ac40577e7518c',1,'imagenES.h']]]
];
